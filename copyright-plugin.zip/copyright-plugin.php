<?php
/*
Plugin Name: Copyright Plugin
Description: Add a Copyright tab to the settings and provide a shortcode for dynamic copyright information.
Version: 1.0
Author: Mahadi Hasan Sizan | #WhitlabelWpDev 
*/

// Add Copyright Settings Page
function copyright_plugin_menu() {
    add_menu_page(
        'Copyright Settings',
        'Copyright',
        'manage_options',
        'copyright-settings',
        'copyright_plugin_page'
    );
}
add_action('admin_menu', 'copyright_plugin_menu');

// Display Settings Page Content
function copyright_plugin_page() {
    ?>
    <div class="wrap">
        <h2>Copyright Settings</h2>
        <form method="post" action="options.php">
            <?php settings_fields('copyright-settings-group'); ?>
            <?php do_settings_sections('copyright-settings-group'); ?>
            <table class="form-table">
            <tr valign="top">
                    <th scope="row">Copyright Text</th>
                    <td>
                        <input type="text" name="copyright_text" Placeholder="%year% Copyright By %site-title% | Design and develop by WhitelabelWpdev"value="<?php echo esc_attr(get_option('copyright_text')); ?>" />
                        <p class="description">To display the copyright text, simply use the [autocopyright] shortcode. To get the current year use  "%year%"  and "%site-title%" to get the site name. </p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Text Color</th>
                    <td>
                        <input type="text" class="color-picker" name="copyright_text_color" value="<?php echo esc_attr(get_option('copyright_text_color', '#000000')); ?>" />
                        <p class="description">Here you can choose the text color, for instance, you can select colors like 'Red' or use hexadecimal color codes like '#2e95d3'.
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Changes'); ?>
        </form>
    </div>
    <?php
}

// Initialize Settings Fields
function copyright_plugin_settings() {
    register_setting('copyright-settings-group', 'copyright_text');
    add_settings_section('copyright-settings-section', 'Copyright Text', 'copyright_settings_section_callback', 'copyright-settings');
    add_settings_field('copyright-text', 'Enter Copyright Text', 'copyright_text_callback', 'copyright-settings', 'copyright-settings-section');
}
add_action('admin_init', 'copyright_plugin_settings');

// Settings Section Callbacks
function copyright_settings_section_callback() {
    echo '<p>Set the copyright text and use %year% and %site-title% placeholders.</p>';
}

function copyright_text_callback() {
    $copyright_text = esc_attr(get_option('copyright_text'));
    echo "<input type='text' name='copyright_text' value='$copyright_text' />";
}

// Enqueue Color Picker Script
function enqueue_color_picker() {
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
}
add_action('admin_enqueue_scripts', 'enqueue_color_picker');

// Save Color Choice
function save_color_choice() {
    register_setting('copyright-settings-group', 'copyright_text_color');
}
add_action('admin_init', 'save_color_choice');

// Modify Shortcode to Display Colored Text
function autocopyright_shortcode() {
    $year = date('Y');
    $site_title = get_bloginfo('name');
    $copyright_text = get_option('copyright_text');
    $text_color = get_option('copyright_text_color', '#000000'); // Default color is black

    $copyright_text = str_replace('%year%', $year, $copyright_text);
    $copyright_text = str_replace('%site-title%', $site_title, $copyright_text);

    // Apply color style
    $colored_text = "<span style='color: $text_color;'>$copyright_text</span>";

    return $colored_text;
}
add_shortcode('autocopyright', 'autocopyright_shortcode');

// Activation Hook
function copyright_plugin_activate() {
    // Activation tasks, if any
}
register_activation_hook(__FILE__, 'copyright_plugin_activate');

// Deactivation Hook
function copyright_plugin_deactivate() {
    // Deactivation tasks, if any
}
register_deactivation_hook(__FILE__, 'copyright_plugin_deactivate');
